package com.example.mycalc

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val spinner: Spinner = findViewById(R.id.spinner)
        // --------------------------------------------------
        // Create an ArrayAdapter using the string array and a default spinner layout
        val adatper = ArrayAdapter.createFromResource(
            this,
            R.array.oprations_array,
            android.R.layout.simple_spinner_item
        )
        adatper.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner.adapter = adatper



        // --------------------------------------------------

        // button
        val calculatebtn: Button = findViewById(R.id.Calculate)

        // Two edit texts
        val num1Et: EditText = findViewById(R.id.etnum1)

        val num2Et: EditText = findViewById(R.id.etnum2)

        val resulttv: TextView = findViewById(R.id.tvresult)

        calculatebtn.setOnClickListener {

            val currentItem = spinner.selectedItem.toString()

            val num1: String = num1Et.text.toString()
            val num2: String = num2Et.text.toString()

            val result = doMath(currentItem, num1.toInt(),  num2.toInt())

            // Result
            resulttv.setText(result)
        }
    }
    fun doMath(item :String, num1: Int, num2: Int ) : String{

        var value = 0
        when(item){
            "addition" -> value = num1+num2
            "subtraction" -> value =  num1-num2
            "multiplication" ->value=  num1*num2
        }
        return value.toString()
    }
}