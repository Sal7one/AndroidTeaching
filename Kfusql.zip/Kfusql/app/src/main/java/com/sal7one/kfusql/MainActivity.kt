package com.sal7one.kfusql

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.sal7one.kfusql.database.Task
import com.sal7one.kfusql.databinding.ActivityMainBinding
import com.sal7one.kfusql.utils.TaskAdapter
import com.sal7one.kfusql.database.TaskDatabaseHelper
import com.sal7one.kfusql.utils.TaskObect


class MainActivity : AppCompatActivity() {

    private lateinit var todoAdapter: TaskAdapter
    private lateinit var myrecyclerView: RecyclerView
    private lateinit var binding: ActivityMainBinding
    val db = TaskDatabaseHelper(this)


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)




        val cursor  = db.readableDatabase.query(Task.Info.TABLE_NAME,null,null,null,null,null,null)

        val list = mutableListOf<TaskObect>()

        with(cursor) {
            while (moveToNext()) {
                val text = getColumnIndexOrThrow(Task.Info.COLUMN_NAME_TITLE)
                 val ischecked = getInt(getColumnIndexOrThrow(Task.Info.COLUMN_NAME_ISCHCKED)) !=0

                list.add(TaskObect(getString(text), ischecked))
            }
        }
        cursor.close()

        binding = DataBindingUtil.setContentView(this, R.layout.activity_main)


        todoAdapter = TaskAdapter(db, list)
        myrecyclerView = binding.taskrecycler

        binding.taskrecycler.adapter = todoAdapter
        binding.taskrecycler.layoutManager = LinearLayoutManager(this)


        binding.addbtn.setOnLongClickListener (){
            todoAdapter.deleteDoneTodos()
            Toast.makeText(this, "Deleted...", Toast.LENGTH_SHORT).show()
            true
        }
        binding.addbtn.setOnClickListener{

            var text = binding.editTextTextPersonName.text.toString()
            if(text.isNotEmpty()){

            val theTask = TaskObect(text, false)
            todoAdapter.addTodo(theTask)
            binding.editTextTextPersonName.text.clear()
            }

        }

        Log.d("MAINACC", todoAdapter.getItemCount().toString())

    }

    override fun onDestroy() {
        db.close()
        super.onDestroy()
    }
}