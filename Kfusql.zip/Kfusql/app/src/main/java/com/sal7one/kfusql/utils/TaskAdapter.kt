package com.sal7one.kfusql.utils

import android.content.ContentValues
import android.graphics.Color
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.sal7one.kfusql.database.Task
import com.sal7one.kfusql.database.TaskDatabaseHelper
import com.sal7one.kfusql.databinding.TaskItemBinding


class TaskAdapter(
    var db: TaskDatabaseHelper,
    private val taskList: MutableList<TaskObect>
) : RecyclerView.Adapter<TaskAdapter.TaskViewHolder>() {


    class TaskViewHolder(val binding: TaskItemBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TaskViewHolder {
        val binding = TaskItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return TaskViewHolder(binding)
    }


    fun deletedata(text: String) {
        var dbread = db.readableDatabase
        val selection = "${Task.Info.COLUMN_NAME_TITLE} LIKE ?"
        dbread.delete(Task.Info.TABLE_NAME, selection, arrayOf(text))
    }


        fun savedata() {
            var dwrite = db.writableDatabase
            dwrite.delete(Task.Info.TABLE_NAME,null,null);

            for (task in taskList) {
            var checked =
                when (task.isChecked) {
                    true -> 1
                    false -> 0
                }
            // Create a new map of values, where column names are the keys
            val values = ContentValues().apply {
                put(Task.Info.COLUMN_NAME_TITLE, task.title)
                put(Task.Info.COLUMN_NAME_ISCHCKED, checked)
            }
            dwrite?.insert(Task.Info.TABLE_NAME, null, values)
        }
    }

    fun addTodo(todo: TaskObect) {
        taskList.add(todo)
        notifyDataSetChanged()
        savedata()
    }

    fun deleteDoneTodos() {
        var arrayofdelte = mutableListOf("")
        taskList.forEach {
            if(it.isChecked){
                arrayofdelte.add(it.title)
                }
            }
        for(element in arrayofdelte){
            taskList.removeAll { it.title == element}
            deletedata(element)
        }
        notifyDataSetChanged()
    }

    private fun greyit(tvTodoTitle: TextView, isChecked: Boolean) {
        if (isChecked) {
            tvTodoTitle.setTextColor(Color.parseColor("#ababab"))
        } else {
            tvTodoTitle.setTextColor(Color.parseColor("#000000"))
        }
    }


    override fun onBindViewHolder(holder: TaskViewHolder, position: Int) {
        val curTodo = taskList[position]
        holder.binding.apply {

            tvTodoTitle.text = curTodo.title
            cbDone.isChecked = curTodo.isChecked
            greyit(tvTodoTitle, curTodo.isChecked)
            cbDone.setOnCheckedChangeListener { _, isChecked ->
                curTodo.isChecked = !curTodo.isChecked
                greyit(tvTodoTitle, curTodo.isChecked)
            }
        }
    }


    override fun getItemCount(): Int {
        return taskList.size
    }

    //    override fun getItemCount() = taskList.size
}

















