package com.sal7one.kfusql.utils

data class TaskObect(
    var title : String,
    var isChecked: Boolean
)
