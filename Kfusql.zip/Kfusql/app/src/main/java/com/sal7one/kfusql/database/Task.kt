package com.sal7one.kfusql.database


import android.provider.BaseColumns

object Task {
        const val SQL_CREATE_ENTRIES =
           "CREATE TABLE ${Info.TABLE_NAME} (" +
                   "${BaseColumns._ID} INTEGER PRIMARY KEY," +
                   "${Info.COLUMN_NAME_TITLE} TEXT," +
                   "${Info.COLUMN_NAME_ISCHCKED} INTEGER)"

        const val SQL_DELETE_ENTRIES = "DROP TABLE IF EXISTS ${Info.TABLE_NAME}"

        object Info : BaseColumns {
            const val TABLE_NAME = "task_table"
            const val COLUMN_NAME_TITLE = "title"
            const val COLUMN_NAME_ISCHCKED =  "ischecked"
        }
    }






